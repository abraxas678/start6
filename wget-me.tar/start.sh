#!/bin/bash
/usr/bin/wget https://raw.githubusercontent.com/abraxas678/start6/master/1m-execute.sh;
chmod +x 1m-execute.sh;
./1m-execute.sh
